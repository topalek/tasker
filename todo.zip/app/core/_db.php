<?php

return [
    "dsn"      => 'mysql:host=127.0.0.1;dbname=todo',
    "user"     => 'test',
    "password" => 'test',
];
