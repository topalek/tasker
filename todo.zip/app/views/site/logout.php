<?php

var_dump(__FILE__);
