<div class="404">
    <h1>404 Error</h1>
    Oops, page not found
    <a href="/">Вернуться на главную</a>
</div>