<?php

use app\core\App;

require_once "../vendor/autoload.php";

$app = new App();